## Version 1.0.0

* Initial release of the package with the following functions included:
`select`, `rename`, `mutate`, `if_else`, `case_when`, `bind_cols`, `bind_rows`, `filter`, `slice`, 
`arrange`, `group_by`, `ungroup`, `group_keys`
