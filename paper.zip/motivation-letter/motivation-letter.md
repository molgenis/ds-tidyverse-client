---
output: pdf_document
fontsize: 12pt
---

\thispagestyle{empty}
\today

Editor   
The R Journal  
\bigskip

Dear Professor Cook,
\bigskip
I am pleased to submit our manuscript, "`dstidyverse': An Implementation of Tidyverse Within the 
DataSHIELD Ecosystem." for consideration in the R Journal. This work presents dsTidyverse, an R 
package that integrates selected Tidyverse functions into the federated analysis platform DataSHIELD, 
significantly improving its usability.

DataSHIELD is a growing [R-based tool]([https://datashield.org/]) for collaborative research across 
multiple institutions, enabling complex statistical analyses without exposing individual-level data. 
However, its data manipulation capabilities remain limited, often requiring cumbersome workarounds. 
dsTidyverse bridges this gap by introducing essential data wrangling functions—such as column 
selection, filtering, grouping, and transformation while maintaining disclosure control. By 
simplifying common data processing workflows, our package enhances user experience and efficiency,
making DataSHIELD more accessible to a broader range of researchers.

We believe that this work will be of interest to researchers in epidemiology, social sciences, and 
other privacy-sensitive fields that rely on DataSHIELD for secure, multi-site collaboration. 

We look forward to receiving your feedback.

\bigskip
\bigskip

Kind regards,
Tim Cadman
    
Department of Genetics, Genomics Coordination Center
University Medical Center Groningen, 
University of Groningen,
Groningen,
The Netherlands

\bigskip
